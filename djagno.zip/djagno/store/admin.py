from django.contrib import admin
from .models import Product, Profile

admin.site.register(Product)
admin.site.register(Profile)
